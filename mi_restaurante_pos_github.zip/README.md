# Mi Restaurante POS

Versión inicial de demostración en un solo archivo.

## Subida a GitHub
1. Sube `index.html` al repositorio.
2. Para una prueba visual, se puede publicar con GitHub Pages.
3. Para uso real del restaurante, el siguiente paso es migrar autenticación,
   pedidos, caja e inventario a un servidor/base de datos.

## Importante
Esta versión es una demostración. No debe usarse todavía como sistema de caja
de producción ni para guardar información sensible. La autenticación del
archivo HTML es solamente para pruebas.
