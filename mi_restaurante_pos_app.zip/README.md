# Mi Restaurante POS — App instalable

Esta versión agrega soporte PWA para instalar el POS como una aplicación desde Safari.

## Archivos
- `index.html` — aplicación POS
- `manifest.webmanifest` — nombre e instalación de la app
- `sw.js` — caché/offline básico
- `icon.svg` — icono de la app

## Instalación en iPhone
1. Publica estos archivos en la raíz de GitHub Pages.
2. Abre la página del POS en Safari.
3. Pulsa Compartir → Añadir a pantalla de inicio.
4. Abre el icono desde la pantalla de inicio.

Nota: esta es una versión de demostración. Para operación real con varios dispositivos,
caja, cocina, inventario y datos compartidos, necesitaremos un backend y una base de datos.
